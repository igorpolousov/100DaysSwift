import Cocoa

// Arithmetic operators

// Here is basic arithmetic operators + add, - subtract , * multiply, / divide, % swift operator for reminders after division

let firstScore = 12
let secondScore = 4

let total = firstScore + secondScore

let difference = firstScore - secondScore

let product = firstScore * secondScore
let divisining = firstScore / secondScore

let reminder = 13 % secondScore

// Operators overloading

let meaningOfLife = 42
let doubleMeaningOfLife = 42 + 42

// It's applicable for strings and arrays
let fakers = "Fakers gonna "
let action = fakers + "fake"

let firstHalf = ["John", "Paul"]
let secondHalf = ["Geoge", "Ringo"]

let beatles = firstHalf + secondHalf

// Compound assignment operators  составные операторы присваивания +=, -=, *=, /=

var score = 95
score -= 5

var quote = " The rain in Spain falls mainly on the "
quote += "Spaniards"

// Comparison operators
let thirdScore = 90
let fourhScore = 5

// equality operator
thirdScore == fourhScore
thirdScore != fourhScore

thirdScore < fourhScore
thirdScore >= fourhScore

// Also you can compare strings

"Tailor" <= "Swift"

// Conditions
// using if operator for crating conditions

let  firstCard = 10
let secondCard = 11

if firstCard + secondCard == 21 {
    print("BlackJack")
} else if firstCard + secondCard == 2 {
    print("Aces - lucky")
} else {
    print("regular cards")
}

// Combining Conditions -  this is || or, && and
let age1 = 21
let age2 = 14

if age1 > 18 && age2 > 18 {
    print("Both are over 18")
}

if age1 > 18 || age2 > 18 {
    print("At least One  is over 18")
}

// Ternary operator

print(firstCard == secondCard ? "Cards the same" : "Cards are differrent")

// regular condition statement

if firstCard == secondCard {
    print("Cards are the same")
} else {
    print("Cards are different")
}


// Switch statements

// if you need to check several conditions it's better to use switch operator

let weather  = "sunny"

switch weather {
case "sunny":
    print("take a sunglasses")
case "snow":
    print("Wrap up warmer")
case "rain":
    print("Taleumbrella")
default:
    print("Enjoy your day")
}
// swift will chek case after case and if case is appropriate it'll stop to check and if you need to continue you have to use word fallthrough and it implement the next case
switch weather {
case "sunny":
    print("take a sunglasses")
    fallthrough // and it implement the next case
case "snow":
    print("Wrap up warmer")
case "rain":
    print("Taleumbrella")
default:
    print("Enjoy your day")
}

// Range operators ... and ..< it allows you to use range of values

let myScore = 95

switch score {
case 0..<50:
    print("You did badly")
case 50..<95:
    print("You did Ok")
default:
    print("You did Great")
}


