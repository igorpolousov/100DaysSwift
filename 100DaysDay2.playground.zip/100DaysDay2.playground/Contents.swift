import Cocoa
// Collections
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

// Simple Array

let beatles = [john, paul, george, ringo]

// Access to the value in Array by index number starts from 0

beatles[1]

// Sets collections
// Another type of collections is Sets: 1 - Items stored without any order. 2 - All item must be unique

let colours = Set(["red", "green", "blue"])
let colours2 = Set(["red", "green", "blue", "red"])

// Tuples collections
// You can't add or remove value from Tuple, they are fixed in size
// You can't change the type of items in Tuple
// You can access to value by numerical position or by naming them
var names = (first: "Taylor", second: "Swift")

names.first
names.0

// Which to use
// If you need specific fixed collection with a precise data it's better to use Tuples

let address = (house: 555, street: "Taylor Swift avenue", city: "Nashville")

// If you need collection where values will be unique it's better to use Sets

let set = Set(["aadvark", "astranaut", "azalea"])

// If you neen collection that contains duplicates or order is matter better to use Arrays

let pythons = ["Terry", "Graham", "John", "Terry", "Terry", "Michael"]

// Dictionary collections
// Almost the same as Arrays, but also you can have access by key [key: value]

let heigts = [
    "Taylor Swift": 1.78,
    "Ad Sheeran": 1.73
]
// Using keys you can read data out of dictionary

heigts["Taylor Swift"]

// If you try to access to key that is not exist Swift will return you nil. Instead of having nil you can declare default value

let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
favoriteIceCream["Paul"]
favoriteIceCream["Charlotte"]
favoriteIceCream["Charlotte", default: "Unknown"]

// Creating an empty collection

// Dictionary
var scores = [String: String]()

// Array
var results = [Int]()

// Sets
var words = Set<String>()
var numbers = Set<Int>()

// Enumerations - enum -  is a way to group related values

let result = "failure"
let result1 = "failed"
let result3 = "fail"

enum Result {
    case success
    case failure
}

let result4 = Result.failure

// enums can store also assosiated values attached to each case. It lets you attach additional information to your enums so they can represent more data

enum Activity {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}

let talking = Activity.talking(topic: "Football")

// You can also assign value to cases

enum Planets: Int {
    case mars = 2 // assigning raw value to item = 2. if you don't it equals = 0
    case earth
    case mercury
    case venus
}
// Numbering starts from 0
let earth = Planets(rawValue: 2)
// but you can also pput your own numbering
let earth2 = Planets(rawValue: 3)


