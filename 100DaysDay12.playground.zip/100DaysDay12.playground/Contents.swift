import Cocoa

// DAY 12, 100 DAYS WITH SWIFT
// OPTIONALS

var age: Int? = nil
age = 38

// Unwrapping optionals with "if let"

var name: String? = nil

if let unwrapped = name {
    print("\(name?.count) letters")
} else {
    print("Missed name")
}

//Unwrapping with Guard

func greet(name: String?) {
    guard let unwrapped = name else {
        print("You didn't provide a name")
        return
    }
    print("Hello \(unwrapped)")
}

greet(name: "Tommy")

// Force unwrapping, если уверен, что занчение нужного типа существеует ставь восклицвтельный знак и разворачивай опционал
let str = "5"
let num = Int(str)!

// Implicitly unwrapped optionals
// Такой метод применяется когда нужно создать переменную без стартового значения, но обязательно при первом использовании этой переменной будет присвоено значение
var age1: Int! = nil

// Nil Coalescing
// при развертывании опционала используется ?? значение по умолчанию, то есть если значение есть, оно будет использовано, если значения нет, будет использовано значение по умолчанию

func userName(for id: Int) -> String? {
    if id == 1 {
        return "Taylor Swift"
    } else {
        return nil
    }
}

let singer = userName(for: 1) ?? "Anonymous"
let singer2 = userName(for: 2) ?? "Anonymous"
print(singer);print(singer2)

// Optional chaining
// Если есть несколько значений и какое-то из них будет nil, то swift сделать всю цепочку nil

let names = ["John", "Paul", "George", "Ringo"]
let beatles = names.first?.uppercased()
print(beatles!)

// Optional try
enum PasswordError: Error {
    case obvious
}
// Есть функция, которая проверяет пароль, и если пароль будет password, будет выдвать ошибку, что пароль очевидный
func checkPassword(_ password: String) throws -> Bool {
    if password == "password"{
        throw PasswordError.obvious
    }
    return true
}
// Пробуем выполнить эту функцию через  do catch
do {
    try checkPassword("password") //  в функции задан очевидный пароль, поэтому он выбросил вариант с ошибкой
    print("The password is good")
} catch  {
    print("You can't use this password")
}
// Можно написать те же условия если задать try как опционал try?

if let result = try? checkPassword("password") {
    print("Result was \(result)")
} else {
    print("D, oh")
}

// Ещё можно записать через try!, НО это если уверенны, что функция не выбросит ошибку
try! checkPassword("Strong")
print("OK!")

// Failalble initializers
// Это инициализвторы, которые могут рабоать а могут и выдать ошибку
// Например, если нам нужно в структуре id длиной не менее 9 символов

struct Person {
    var id: String
    
    init?(id: String) {
        if id.count >= 9 {
            self.id = id
        } else {
            return nil
        }
    }
}

if let person1 = Person(id: "Trattorilal") {
    print(" Person ID is \(person1.id)")
} else {
    print("ID length is too short")
}

// Type casting
//  Я не очень понял, что значит type casting, но в примере есть ключевое слово as?

class Animal { }
class Fish: Animal { }
class Dog: Animal {
    func makeNoise() {
        print("Woof")
    }
}

let pets = [Fish(), Dog(), Dog(), Fish()]

for pet in pets {
    if let dog = pet as? Dog {
        dog.makeNoise()
    }
}
