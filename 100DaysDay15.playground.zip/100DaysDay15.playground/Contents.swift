import Cocoa



// Day 15, 100 Days with Swift
// 1 Properties
// 2 Static properties and methods
// 3 Access control
// 4 Polymorfism and typecasting
// 5 Closures


// 1 Properties
// Структуры и классы могут содержать свойства и методы. Так же есть properties observers. Наблюдатели свойств.

struct Person {
    var clothes: String // свойство
    var shoes: String // свойство
    
    func describe() {        // метод
        print("I like wearing \(clothes) with \(shoes)")
    }
}

let taylor = Person(clothes: "T-shirts", shoes: "Sneakers")
let other = Person(clothes: "Short skirts", shoes: "High heels")

taylor.describe()
other.describe()


// Properties observers - willSet and didSet

struct Person1 {
    var clothes: String {
        willSet {
            updateUI(msg: "I'm changing from \(clothes) to a \(newValue) ")
        }
        didSet {
            updateUI(msg: "I just changed from \(oldValue) to \(clothes)")
        }
    }
    func updateUI(msg: String) {
        print(msg)
    }
}

var  taylor1 = Person1(clothes: "T-Shirts")
taylor1.clothes = "short skirts"


// Computed properties get and set
// Если испоьлзуется только get, то слово get вообще можно опустить

struct Age {
    var age: Int
    
    var ageInDogYears: Int { // Вычисляемое свойство структуры Age
        get {
            return age * 7
        }
    }
}

var person2 = Age(age: 15)
print(person2.ageInDogYears)

// 2 Static properties and methods
// Swift позволяет создавать статичные свойства, которые больше принадлежат структуре, а не экземпляру структуры. Другими словами статичное свойство будет у каждого экземлпяра структуры вне зависимости каким инициализатором этот экземпляр был создан memberwise or custom

struct TaylorFun {
    static var favoriteSong = "Look what you made me do"
    
    var name: String
    var age: Int
}

var fun = TaylorFun(name: "Timmy", age: 24)
print(TaylorFun.favoriteSong)

// Access control
// Можно ограничить доступ к какому-то свойству типа чтобы оно было доступно только для методов этого типа или для его расширений - используется private
// Можно ограничить доступ так чтобы свойство было доступно только внутри файла - используется ключевое слово fileprivate

class TaylorFun1 {
    private var name: String?
}

class TaylorFun2 {
    fileprivate var name: String?
}

// Polymorphism and type casting
// Type casting - это возможность в Swift изменить тип данных as! or as?
// Polymorphism - это возможность рассматривать экземпляр как принадлежащий к суперклассу так и к сабклассу
// Создадим три класса, один суперкласс  Album и два наследника этого класса StudioAlbum and LiveAlbum
class Album {
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    func getPerfomance() -> String {
        return "The album \(name) sold lots"
    }
}

class StudioAlbum: Album {
    var studio: String
    
    init(name: String, studio: String) {
        self.studio = studio
        super.init(name: name)
    }
    override func getPerfomance() -> String {
        return "The studio album \(name) sold lots"
    }
}

class LiveAlbum: Album {
    var location: String
    
    init(name: String, location: String) {
        self.location = location
        super.init(name: name)
    }
    override func getPerfomance() -> String {
        return "The live album \(name) sold lots"
    }
}

// Создадим три экземпляра класса. Два StudioAlbum и один LiveAlbum

let taylorSwift = StudioAlbum(name: "Taylor Swift", studio: "Casles studio")
let fearless = StudioAlbum(name: "Speak now", studio: "AimeeLand studio")
let iTunesLive = LiveAlbum(name: "iTunes Live from SoHo" , location: "New York")

// И теперь можно создать массив с типом данных Album в который можно включить, все созданные экземпляры , хотя они и являются экземплярами других классов
var allAlbums: [Album] = [taylorSwift, fearless, iTunesLive] // пример полиморфизма, когда экземпляры могут быть разных типов данных и могут рассматриваться как другой тип данных

// В классах есть метод getPerfomance() и можно для какждого из экземпляров вызвать этот метод, но вместе с тем каждый экземпляр выполнит этот метод согласно своего класса

for album in allAlbums {
    print(album.getPerfomance())
    
    if let studioAlbum = album as? StudioAlbum {
        print(studioAlbum.studio)
    } else if let liveAlbum = album as? LiveAlbum {
        print(liveAlbum.location)
    }
}


// Converting type with type casting
// Optional downcasting  используется as?
// Forced downcasting использутеся as!
// Converting with ?? coalescing
// Converting common types with initializer

let number = 5
let string = String(number)
print(string)

let num1 = 2
let num2 = 3.2
let num3 = Double(num1) + num2 // если просто укзать, что нужно сложить num1 и num2
print(num3)


// Closures
// Замыкания как-то он коротко повторил((

var numberNine: Double = {
    num3 * num2
}()
print(numberNine)
