import Cocoa

// DAY 14, 100 DAYS WITH SWIFT
// 1 Functions
// 2 Optionals
// 3 Optional chaining
// 4 Enumeration
// 5 Structs
// 6 Classes

// 1 Functions
// Это пример функции, которая не принимает никаких параметров, просто исполняет часть кода
//func myFavoriteAlbum() {
//    print("My favorite album is Fearless")
//}
//
//myFavoriteAlbum()

// Такая же функция, но которая принимает параметр

func myFovoriteAlbum(name: String) {
    print("My favorite album is \(name)")
}

myFovoriteAlbum(name: "Fuck your ass")

func albumReleased(name: String, year: Int) {
    print("\(name) was released in \(year)")
}

albumReleased(name: "Fearless", year: 2008)

// Можно задать входной параметр 3 способами: 1 способ как указано в функции выше, второй вариант -  указать имя коорое будет видно при вводе параметра

func albumReleased1(in year: Int) {
    print("Album released in \(year)")
}

albumReleased1(in: 2010)

// Третий вариан это когда можно вообще сделать что при вводе параметра не видно название параметра, для этого используется нижнее подчеркивание

func albumReleased2(_ year: Int) {
    print("Album was released in \(year)")
}

 albumReleased2(2020)

// Optionals
// Самая распространенная ошибка, которая приводит к app crash - это использование данных которые не верного типа или данные отсутсвуют
// Чтобы привести optional к требуемому типу данных существует несколько методов: force unwrap, if let, guard let
// Немного практики в написании кода))

func yearAlbumReleased(name: String) -> Int? {
    if name == "Taylor Swift" { return 2009}
    if name == "Fearless" { return 2006}
    if name == "Red" {return 2012}
    return nil
}

var year = yearAlbumReleased(name: "Taylor Swift")

if year == nil {
    print("There was an error")
} else {
    print("The album released year is \(year!)") // поскольку известно, что будет верное значение, применил force unwraped
}

// Optional chaining

func albumYear(year: Int) -> String? {
    switch year {
    case 2006: return "Taylor Swift"
    case 2008: return "Fearless"
    case 2012: return "Red"
    default: return nil
    }

}

let album = albumYear(year: 2012)
print("The album name is \(album ?? "There was no album this year")") // optional coalescing - означает, что если значение будет равно nil, то будет применено значение после ??, предоставляется дефолтное значение. Это так же способ привести optional  к определенному типу данных
album?.uppercased() // - это пример optional chaining, когда в значении есть часть, которая является optional

// Enumerations. Это простой способ создать свой тип данных, например: погода. В таком случае, если указать что переменная погода будет равна созданной переменной, то в таком случае переменная сможет принять значения только созданного вами типа данных

enum Weather: String {
    case drizzle
    case rainy
    case sunny
    case snowy
}

func getHaterStatus(weather: Weather) -> String? {
    if weather == Weather.drizzle {
        return "Hate"
    } else {
        return nil
    }
}

let status = getHaterStatus(weather: .rainy) // можно просто использовать точку и не писать название enum чтобы выбрать значение
print("\(status ?? "Nothing at all")")

// Можно так же сделать условие через switch, если используется switch, то либо должны быть указаны все возможные варианты, либо должно быть указано значение по умолчанию

func getHaterStatus1(weather: Weather) -> String? {
    switch weather {
    case .drizzle,.rainy:
        return "Hate"
    case .sunny,.snowy:
        return "Nothing"
    }
}
getHaterStatus(weather: .drizzle)

// enum can also adde extra condition to the case block: case wind(speed: Int)
// так же нужно быть внимательным когда делаешь перечисление случаев в switch, потому что swift проверяет свеху вниз и если занчение подошло, то будет принято оно. так что если есть случай в котором указана  скорость ветра и просто ветер, то нужно расположить случай со скоростью ветра выше случая просто с ветром

enum Weathertype {
    case sun
    case cloud
    case wind(speed: Int)
    case snow
    case rain
}

func getHaterStatus2(weather: Weathertype) -> String? {
    switch weather {
    case .sun:
        return nil
    case .wind(let speed) where speed < 10:
        return "meh"
    case .wind, .cloud:
        return "Dislike"
    case .snow, .rain:
        return "Hate"
    }
}

getHaterStatus2(weather: .wind(speed: 12))

// Structs это тоже способ создать свой тип данных. Это тип данных со значанием, если создать две переменных со свойствами структуры и присвоить одной переменной значение другой переменной, а потом в одной из переменных поменять занчение одного из свойств , то поменяется значение только в той переменной, в которой производили замену

struct Person {
    var name: String
    var age: Int
    var shoes: String
    
    func personData() {
        print("My name is \(name) and my age is \(age) and I'm wearing \(shoes)")
    }
}

let taylor = Person(name: "Taylor", age: 13, shoes: "Sandals")
let john = Person(name: "John", age: 15, shoes: "Boots")

var sarah = taylor
sarah.shoes = "Sneakers"
sarah.name = "Sarah"
print(sarah.shoes)
print(taylor.shoes)

// Структуры могут так же содержать функции - называются методы, чтобы поменять значение свойства нужно использовать mutating func

sarah.personData() // использование метода в сруктуре

// Classes это так же тип данных, только ссылочный, если приравнять две переменных и потом поменять в одной из переменных значение свойства, будет произведена замена в обоих переменных

// Классы требуют создания инициализатора
// Классы могут наследовать свойства от других классов и тогда нужно созадавать инициализотор для обоих

class Persons {
    var clothes: String
    var shoes: String
    
    init(clothes: String, shoes: String) {
        self.clothes = clothes
        self.shoes = shoes
    }
}

var john1 = Person(name: "John", age: 18, shoes: "Boots")

class Singer {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    func sing() {
        print("LA LA LA")
    }
}

// Создадим еще один класс наследник

class CountrySinger: Singer {
     override func sing() {
        print("Trucks, guitars and liquor")
    }
}

// Создадим еще один класс наследник, но в котором уже будет еще одно свойство noise

class MetalSinger: Singer {
    var noiseLevel: Int
    
    init(name: String, age: Int, noiseLevel: Int) {
        self.noiseLevel = noiseLevel
        super.init(name: name, age: age)
    }
    
    override func sing() {
        print("Raagh Ragh Raaaahgh")
    }
}

let singer = Singer(name: "John", age: 23)
singer.age
singer.name
singer.sing()

let countrySinger = CountrySinger(name: "Taylor", age: 21)
countrySinger.sing()
countrySinger.age
countrySinger.name

let metalSinger = MetalSinger(name: "Hugh", age: 34, noiseLevel: 23)
metalSinger.noiseLevel
metalSinger.age
metalSinger.name
metalSinger.sing()

