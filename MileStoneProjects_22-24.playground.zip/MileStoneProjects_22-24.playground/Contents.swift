import UIKit
// Day 82
// Milestone Projects22-24

var greeting = "Hello, playground"

// Challenge 1 UIView bounceOut(duration: TimeInterval)
extension UIView {
    func bounceOut(duration: TimeInterval) {
        UIView.animate(withDuration: duration) {
            self.transform = CGAffineTransform(scaleX: 0.0001, y: 0.0001)
        }
    }
}


// Challenge 2
extension Int {
    func times(handler: () -> Void) {
        guard self > 0 else { return }
        for _ in 1 ... self {
            handler()
        }
    }
}

// Challenge 3
extension Array where Element: Comparable {
    mutating func remove(item: Element) {
        if let index = self.firstIndex(of: item) {
            remove(at: index)
        }
    }
}
