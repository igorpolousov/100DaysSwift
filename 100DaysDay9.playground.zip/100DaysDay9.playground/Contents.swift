import Cocoa

// DAY 9, 100 DAYS WITH SWIFT
// Structs part 2

// Initialazers
// There are two main initialazers for struct: memberwise initializer - assign struct to var or let and you should be suer that all struct properties has a value. Custom initializer - you can create initializer inside the struct, no need to values to the properties during struct creation

// memberwise initializer

struct Person1 {
   var name: String
}

var person1 = Person1(name: "Sally")
print(person1.name)

// Custom initializer

struct Person2 {
    var name: String
    
    init() {
        name = "Ananimous"
        print("\(name) was born")
    }
}

var person2 = Person2()
print(person2.name)
person2.name = "Wally"
print(person2.name)

// Reffering to the current instance
// if you need to create initializer and property name is the same as parameter name you can use self(starts from small s)
// Если тебе надо написать инициализатор, который будет принимать параметр, и имя этого параметра будет такое же как и имя свойства структуры, то нужно написать перед свойством структуры слово self. чтобы Swift понимал что имеется ввиду своство структуры.
struct Person3 {
    var name: String // переменная name - как свойство структуры
    
    init(name: String) { // константа name - как принимаемый параметр при создании экземпляра структуры
        print("\(name) was born")
        self.name = name // указываем, что name в структуре = name - принимаемы параметр
    }
}

var person3 = Person3(name: "Johnny")

// Lazy properties Ленивые свойства
// Если создать структуру, и у структуры будет свойство перед которым будет указано lazy, то такое свойство будет использовано только если будет создан запрос непосредственно у этому свойству

struct FamilyTree {
    init() {
        print("Creating family tree")
    }
}

struct Person4 {
    var name: String
    var familyTree = FamilyTree()
    
    init(name: String) {
        self.name = name
    }
}

var person4 = Person4(name: "Tommy") // можно видеть что произошла печать из структуры FamilyTree

// Структура с указанием lazy

struct Person5 {
    var name: String
   lazy var familyTree = FamilyTree()
    
    init(name: String) {
        self.name = name
    }
}

var person5 = Person5(name: "Tommy") // there is no print form FamilyTree Struct
person5.familyTree // после этой строки произошел print from FamilyTree struct

// Static properties and methods
// Можно сделать так чтобы Swift присваивал каждому экземпляру структуры специальное свойство, перед таким свойством нужно укзать static. В примере инициализация этого свойства произведена присваиванием параметра свойству сразу в структуре

struct Student {
   static var classSize = 0
    var name: String
    
    init(name: String) {
        self.name = name
        Student.classSize += 1
    }
}

var stud1 =  Student(name: "Shally")
print(Student.classSize)
var stud2 = Student(name: "Billie")
var stud3 =  Student(name: "I am")
print(Student.classSize)

// Access control
// Перед свойством структуры можно укзать слово struct  и в таком случае доступ к значению этого свойства будет только у методов, написанных внутри этой структуры

struct Person6 {
    private var id: Int
    
    init(id: Int) {
        self.id = id
    }
    
    func identify() {
         print("My social security number is \(id)")
    }
    
}

let ed = Person6(id: 12345)
ed.identify()
