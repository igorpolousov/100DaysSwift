import Cocoa

// DAY 11, 100 DAYS WITH SWIFT
// PROTOCOLS AND EXTENSIONS

// Протоколы нужны чтобы описать какими свойствами и методами что-то должно иметь.

protocol Identifiable {
    var id: String { get set} //  структура или класс должны будут соотвествовать протоколу и иметь свойство id: String, клторое может быть get - свойство можно прочитать, set - значит свойство может быть задано
}

struct User: Identifiable {
    var id: String
}

func displayID(thing: Identifiable) { // задается константа thing, которая имеет свойство id
    print("My id is \(thing.id)") // сразу задано что будет печать свойсва id
}

// Protocol inheritance
// В отличии от классов можно наследовать сколь угодно протоколов одновременно

protocol Payable {
    func calculateWages() -> Int
}

protocol NeedsTraining {
    func study()
}

protocol HasVacation {
    func vacation(days: Int)
}

protocol Employee: Payable, NeedsTraining, HasVacation {} // в конце строки с указанием наследования протоколов написать {}

// Extensions
// Расширения позволяют добавлять методы к уже существующим типам
// Для примера к типу Int добавим раширение с методом который будет умножать число само на себя

extension Int {
    func squared() -> Int {
        return self * self
    }
}

let number = 8 // создали переменную с параметром 8 и типом Int
number.squared() // теперь эта переменная имеет метод squared

// Пример расширения в котором будет описан метод isEven  и будет проверяться четное число или нет
// Swift  не позволяет в расширениях прописывать заданные значения, но можно прописывать вычисляемые значения
extension Int {
    var isEven: Bool {
        return self % 2 == 0
    }
}

number.isEven

// Protocol exstensions
// Расширения для протоколов позволяет добавить раширения для всех типов, которые соотвествуют этому протоколу. Тогда как расширения для типов позволяют добавить расширение к указанному типу

let pythons = ["Jerry", "Terry", "Eric", "Graham", "Martin", "Martin"]
let beatles = Set(["John", "Paul", "Geoge", "Ringo"])
// наборы и массивы оба соотвествуют протоколу collection,  поэтому создав расширение для collection будет создано расширение сразу для обоих типов

extension Collection {
    
    func summurize() {
        print(" There are \(count) of us")
        
        for name in self {
            print(name)
        }
    }
}

pythons.summurize()
beatles.summurize()

// Protocol oriented programming

protocol Identify {
    var id: String { get set }
    func identify()
}

extension Identify {
    func identify() {
        print("My ID is \(id)")
    }
}

struct Users: Identify {
    var id: String
}


let twoStraws = Users(id: "twoStraws")
twoStraws.identify()
