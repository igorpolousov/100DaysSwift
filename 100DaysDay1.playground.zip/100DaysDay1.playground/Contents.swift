import Cocoa
// Lesson 1. Is just How to create variables. Первый урок просто про то как создавать переменные и присваивать им значения. Чтобы присвоить значение переменной нужно укзать слово var и затем указать название переменной и после знака  = укзать значение для переменной
var str = "Hello, playground"
str = "GoodBye"

var age = 38 // Is Integer value Int

// If number is too long you can use this_

var papulation = 8_000_000 // The population is equal to 8 000 000

// If you want your Stirng code contains multilines you must use """ String """

var str1 = """
Hi
it's
very
good
"""

// Or you can use \ for defining multiple lines(if you dont want to see \ in your line)

var str2 = """
This goes \
multiple \
lines
"""

// There're two os basic types of data Double and Bool. Double is a number with a dot  like 3.14, and Bool is contains booleans type with state true or false

var pi = 3.14 // Double

var awesome = true // Bool


// String interpolations - is ability to palce variables inside your String. For adding use inside String \(var)

var score = 85
var str3 = "Your score is \(score)"
var results = """
The test results are here: \
\(str3)
"""

// If you won't change a value you need to use a constant instead of variable. the key word for constant is let

let taylor = "Swift"

// Type Annotations

// Swift assign each variable and constant a type based on what value it's given when it was created
// If you want to add type to var or let you can make it after :

var album: String = "Reputation"
var year: Int = 1989
var height: Double = 1.78
var taylorRocks: Bool = true
