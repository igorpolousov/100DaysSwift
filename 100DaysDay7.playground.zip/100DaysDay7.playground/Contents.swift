import Cocoa

// DAY 7, 100 DAYS WITH SWIFT
// CLOSURES PART 2. Repeating closures
// Using clouse as parameter when they accept patameter

func travel( action: (String) -> Void) {
    print("I'm getting ready to go")
    action("London")
    print("I arrived")
}

travel{ (place: String) in
    print("I'm going to \(place) in my car")
}

// Using closure as parameters when they return value
func travel1(action:(String) -> String) {
    print("I'm getting ready to go")
    let description = action("Moscow")
    print(description)
    print("I arrived")
}

travel1{ (place: String) -> String  in
    return "I'm going to \(place) in my car"
}

// Shorthand parametr name
// Можно код в строках 25 26 написать более коротко, потому что Swif поддерживает короткие имена

travel1{
    "I'm going to \($0) in my car"
}

// Closures with multiple parametrs

func travel3(action:(String, Int) -> String) {
    print("I'm getting reafy to go")
    let description = action("Tula", 60)
    print(description)
    print("I arrived")
}

travel3{
    "I'm going to \($0) in my car by \($1) miles per hour"
}

// Returning closures from function

func travel3() -> (String) -> Void {
    var counter = 1
    return {
        print("\(counter). I'm going to \($0)")
        counter += 1
    }
}
let result = travel3()
result("Istra")
result("Moscow")

// Capturing values Захватываемые значения
// можно добавить значение в функцию и потом поместить это значение в замыкание. Несмотря на то, что counter был создан внутри функции замыкание всё равно может захватывать это значение.

