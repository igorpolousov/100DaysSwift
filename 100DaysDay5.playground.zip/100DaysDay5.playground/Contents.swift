import Cocoa

// Продолжаем импортировать какао и делать курс от Paul Hudson
//  DAY 5, 100 DAYS WITH SWIFT

// Functions. Functions help us to re-use code. repeating cod is bad idea, so function help to avoid diong that.

// functions starts from word func

func printHelp() {
    let message = """
    Welcome to MyApp!
    
    Run MyApp inside the directory of images
    MyApp will resize them all into thumbnails
    """
    print(message)
}

// Run the function often reffered to as called function
// calling  function printHelp()

printHelp()

// Functions can be more powerfull when they can accept parameters every time you run it
// Нужно дать каждому параметру название и затем после двоеточия указать тип параметра

// MARK ACCEPTABLE PARAMETRS
func square(number: Int) { // That tells Swift we expected to receive an Int and it called number
    print(number * number)
}
square(number: 8
)

// MARK RETURNING VALUES
// Так же как и получать данные функция может и возвращать данные. Используется ключевое слово return, после это слова никакой код в функции не будет выполняться.

func cube(number: Int) -> Int{
    return Int(pow(Double(number), 3)) // If you need to return multiple values it's perfect to use here tuples
}

var cubeNumber = cube(number: 4)
print(cubeNumber)


// MARK this is an example of returning tuples
func squareCube(number: Int) -> (Int, Int) { // telling swift what kind of data should be returned
    let square = Int(pow(Double(number),2))
    let cube = Int(pow(Double(number),3))
    return (square, cube)
}
//MARK example of using fucntion with tuples
let example = squareCube(number: 2)
print(example.0)
print(example.1)
print(example)

//PARAMETER LABLES
//Swift let us to provide two names% internal and external. internal will be used when the function asks to tell an item and internal is for using inside a function

func sayHello(to name: String){ // "to" is external and "name" is internal
    print("Hello, \(name)")
}

sayHello(to: "Taylor")

//OMITTING PARAMETER LABLES, пропуск параметров
// If it's necessery you can omit name lable usin underscore _ , можно сделать так чтобы при вызове функуции не было видно внутреннего имени, для этого необходимо использовать подчеркивание и пробел

func setAlarm(_ time: Int){
    print(time)
}

let alarm: () = setAlarm(5)

// MARK DEFAULT PARAMETERS  параметры по умолчанию
// You can set your default parameter for a value using =

func greet(_ person: String, nicely: Bool = true) {
    if nicely == true {
        print("Hello \(person)")
    } else {
        print("Oh no, it's \(person) again...")
    }
}

greet("Taylor")
greet("Taylor", nicely: false)

// VARIADIC FUNCTIONS if you pass a lot if parameters they are all printed in one line with spaces between them

func multySquare(numbers: Int...) {
    for number in numbers {
        print("\(number) squared is \(number * number)")
    }
}

multySquare(numbers: 1, 2, 3, 4)

// WRITING THROWING FUNCTIONS
// use throw function when something can go wrong, first you need to do an enum

enum PasswordError: Error {
    case obvious
}

func passwordCheck(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    return true
}


//RUNNING THROWING FUNCTIONS
// Если возможны ошибки при запуске функции то для запуска такого кода нужно использовать три основных слова
// do start the section of code which can cause error
//try is used before every functions can throw error
// catch let you handle errors

do {
    try passwordCheck("password")
    print("That password is good")
} catch {
    print("You can't use this password")
}

//INOUT PARAMETERS  все парметры в функциях Swift являются константами. Если нужно чтобы значение менялось нужо использовать inout parameters

func doubleInPlace(number: inout Int) {
    number *= 2
    print(number)
}

// Then you need to use variable integer
var myNum = 10
doubleInPlace(number: &myNum)
