import Cocoa

// DAY 6, 100 DAYS WITH SWIFT
// CLOSURES PART 1

// CREATING BASIC CLOSURE
// Swift allows to use functions as any other types like strings ans integers

let driving =  {
    print("I'm driving a car")
}
// You can call function the same way as usual function
driving()

// ACCEPTING PARAMETER IN A CLOSURE
// Для того чтобы замыкание принимало параметр нужно в скобках написать параметр и его тип и после закрытия скобки написать in

let walking = { (place: String) in
    print("I'm walking in the \(place)")
}

walking("Moscow")

// RETURNIG VALUE FROM THE CLOSURE

let walkingWithReturn = { (place: String) -> String in
    return "I'm walking to the \(place)"
}
let test = walkingWithReturn("Sport master")
print(test)

// CLOSURES AS PARAMETERS
// Если нужно чтобы функция принимала замыкание нужно в принимаемом параметре указать () -> void
// Можно написать функцию travel() чтобы она принимала разные действия action()

func travel(action: () -> Void) {
    print("I'm getting ready to go")
    action()
    print("I arrived")
}
travel(action: driving)

// TRAILING CLOSURE SYNTAX
// Trailing closure syntax  позволяет написать код прямо при вызове функции. В примере выше параметр передается в виде уже готового кода, в примере ниже код написан прямо при вызове функции
travel {
    print("I'm driving a car")
}

// USING CLOSURE AS PARAMETER WHEN CLOSURE ACCEPT PARAMETER
// Нужно еще раз посмотреть этот момент

func travel1(action: (String) -> Void) {
    print("I'm getting ready to go")
    action("London")
    print("I arrived")
}

travel1 { (place: String) in
    print("I'm going to \(place) in my car")
}

// USING CLOSURES AS PARAMETER WHEN THEY RETURN VALUE

func travel2(action:(String) -> String){
    
    print("I'm going in my car")
    let description = action("London")
    print(description)
    print("I arrived")
}
travel2 { (place: String) -> String in
    return "I'm going to \(place) in my car"
}

//SHORTHAND PARAMETER NAMES
// Вот это я вообще не понял, просто напишу код из урока
travel2 {
    "I'm going to \($0) in my car"
}

// CLOSURES WITH MULTIPLE PARAMETERS
func travel3(action: (String, Int) -> String) {
    print("I'm getting ready to go")
    let description = action("Paris", 60)
    print(description)
    print("I arrived")
}

travel3 {
    "I'm going to \($0) with \($1) miles per hour"
}

// RETURNING CLOSURES FROM FUNCTIONS
// paranthesis = скобки

func travel2() -> (String) -> Void {
     var counter = 1
    return {
        print("\(counter). I'm going to \($0)")
        counter += 1
    }
}
let result = travel2()
result("New York")
result("New York")



//CAPTURING VALUES внесены изменения выше

