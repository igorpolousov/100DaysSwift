import Cocoa

// 100 Days Day 4
// Loops. run the same code repeatedly until a condition evaluates as false
// The first way to writing loops is using for
let count = 1...10

for number in count {
    print("The number is \(number)")
}

let albums = ["Red", "1989", "Reputation"]

for album in albums {
    print("\(album) is in the Apple music")
}

print("Players gonna ")

for _ in 1...5 {
    print("play")
}

// The second is using while

var number = 1

while number <= 5 {
    print(number)
    number += 1 // if inn the cycle you didn't add this line you will have a very big loop))
}

print("Cyber dome")

// Third type of loops is repeat while

// using var number again

repeat {
    print(number)
    number += 1
} while number <= 10

print("Ready or not I'm here")

while false {
    print("This is false") // this code never will be run
}
// if you want to print it at least once use repeat
repeat {
    print("This is false")
} while false

// The next is exiting loops
var countDown = 10

while countDown >= 0 {
    print(countDown)
    countDown -= 1
    if countDown == 4 {
        print("I'm bored")
        break
    }
}

print("You is run out")

// Exiting multiple loops, nested loops

for i in 1...10 {
    for j in 1...5 {
        let product = i + j
        print("\(i) + \(j) is \(product)")
    }
}

// if we want to exit part time it's need to give a loop a lable and add "if condition"

outerLoop: for a in 1...3 {
    for b in 1...3{
        let summury = a + b
        print("\(a) + \(b) is \(summury)")
        
        if summury == 5 {
            print("It's a good mark")
            break outerLoop // if you use "break" without lable it will stops inly an inner loop
        }
    }
}

// Skipping items
// use "continue" to continue the loop and skip condition

for y in 1...10 {
    if y % 2 == 0{
    continue
    }
    print(y)
}

// Infinite (бесконечные) loops or if you want to exit loop after you'll ready
var counter = 0

while true {
    print(counter)
    counter += 1
    if counter == 50 {
        break
    }
}
