import Cocoa

// Hello Swift
// DAY 10, 100 DAYS WITH SWIFT
// Всего 5 главных отличий от структур: есть только custom initializer,  классы можно наследовать, чтобы поменять метод суперкласса нужно написать слово override, при копировании присходит изменение в обоих экземплярах класса, потому что ссылочный тип, могут иметь deinitializers,  можно менять парметр свойства класса даже если экземпляр класса создан как константа
// Classes and inheritance классы и наследование

// Классы так же позволяют сделать собственные типы с собственными свойствами и методами. Отличие от структур то , что необходимо обязательно делать custom initializer

class Dog {
    var name: String
    var breed: String
    
    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
    }
}

let dog1 = Dog(name: "Poppy", breed: "Poodle")

// Inheritance and superclasses superclass and subclass
// Классы согут наследовать свойства других классов. Получится суперкласс и подкласс. Для подкласса так же необходимо создавать инициализатор суперкласса

class Poodle: Dog {
    init(name: String) {
        super.init(name: name, breed: "Poodle")
    }
}

// Method ovverriding
// Если нужно изменить метод из суперкласса , используется слово override

class Dog1 {
    func makeNoise() {
        print("Woof")
    }
}

class Poodle1: Dog1 {
    override func makeNoise() {
        print("Yip")
    }
}

let poodle = Poodle1()
poodle.makeNoise()

// Final classes
// Если нужно сделать так чтобы больше не было наследников класса, то используется ключевое слово final

 final class Dog2 {
    var name: String
    var breed: String
    
    init(name: String, breed: String) {
        self.name = name
        self.breed = breed
        print("Dog name is \(name), dog breed is \(breed)")
    }
}
let dog2 = Dog2(name: "Tuppy", breed: "Poodle")

// Copuing objects  копирование объектов
// Классы являются ссылочным типом данных и поэтому если создать копию объекта и поменять в этой копии значение, то значение поменяется в обоих экземплярах


class Singer {
    var name = "Taylor Swift"
    
}

var singer = Singer()
print(singer.name)

var singerCopy = singer
singerCopy.name = "Tommy"
print(singerCopy.name)
print(singer.name) // Произошла замена параметра свойства name  в обоих экземлпярах класса

struct Singers {
    var name = "Taylor Swift"
}

let singers = Singers()
print(singers.name)

var singersCopy = singers
singersCopy.name = "Tommy"
print(singers.name)
print(singersCopy.name) // Каждый экземпляр структуры остался с первоначалным параметром свойства name


// Deinitializers
// Деинициализатор - это код, который запускается когда экземпляр класса удаляется

class Person {
    var name = "John Doe"
    
    init() {
        print("\(name) is alive!")
    }
    
    func printGreeting() {
        print("Hello, I'm \(name)")
    }
    deinit {
        print("\(name) is no more")
    }
}

for _ in 1...3 {
    let person = Person()
    person.printGreeting()
}

// Mutability
// Если экземпляр класса создан как константа, а свойство класса задано как переменная, то чтобы поменять параметр свойства класса можно просто задать новый параметр. Если нужно, чтобы параметры свойства в классе не менялись, свойство так же нужно создать как константу
//В структурах так сделать нельзя. Если структура задана как константа, а свойство структуры задано как переменная, изменить параметр свойства нельзя, нужно писать mutating func для изменения параметра свойства

class Singer1 {
    var name = "Taylor Swift"
}
let taylor = Singer1()
print(taylor.name)
taylor.name = "Ed Sheeran"
print(taylor.name)

struct Singer3 {
    var name = "Taylor Swift"
    
}

let singer3 = Singer3()
print(singer3.name)
//singer3.name = "Ed Sheeran" // Show mistake

var singer4 = Singer3()
singer4.name = "Ed Sheeran" // Если задать структуру как переменную то можно поменять параметр свойства структуры
print(singer4.name)
