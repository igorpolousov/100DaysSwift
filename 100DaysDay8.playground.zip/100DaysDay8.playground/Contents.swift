import Cocoa

// DAY 8, 100 DAYS WITH SWIFT
// STRUCTS PART 1

// Ceating your own structs
// Структуры - это способ создать свой тип данных в Swift. В структурах можно создавать свои константы и переменные и писать свои функции, которые потом можно импользовать как нужно.

struct Sport {
    var name: String
}

var tennis =  Sport(name: "Tennis")
print(tennis.name)

tennis.name = "Lawn tennis"

// Computed properties
// Вычисляемое свойство - это свойство для получения которого необходимо запустить выполнение кода

struct Sport1 {
    var name: String
    var isOlympicSport: Bool
    
    var isOlympicStatus: String {
        if isOlympicSport {
            return "\(name) is an Olympic sport"
        } else {
            return "\(name) is not an Olympic sport"
        }
    }
}

var boxChess = Sport1(name: "BoxChess", isOlympicSport: false)
print(boxChess.isOlympicStatus)

// Property observers. Наблюдатели свойств
// You can use "didSet" property observer, it will run some code every time the property will be changed

struct Progress {
    var task: String
    var amount: Int {
        didSet {
            print("\(task) is now \(amount)% complete")
        }
    }
}

var progress = Progress(task: "Data loading", amount: 30)
progress.amount = 50
progress.amount = 80
progress.amount = 100 // Каждый раз как будет изменялось свойство amount запускался кодс и печаталась строка

// Methods. Функции внутри структуры называются методы по прежнему начинается со слова func  и принадлежит структуре. Во всплывающей подстказке отображается как синяя буква м. Отличие от наблюдателей тем что, наблюдатель сам запускает код когда происходит изменение значения, а чтобы исполнилась функция нужно запускать её в ручную
struct Population {
    var population: Int
    
    func taxes() -> Int {
        return population * 100
    }
}
var london = Population(population: 2000)
print(london.taxes())

// Mutating methods
// Swift  не даёт поменять значение свойства структуры. Чтобы метод мог поменять значение свойства структуры, перед методом нужно писать слово mutating

struct Person {
  var name: String
    
    mutating func makeAnonymous() {
       name = "Anonymous"
    }
}

var person = Person(name: "Ed")
print(person.name)
person.makeAnonymous()
print(person.name)


// Properties and methods of strings
// Свойства и методы строк. Строки являются так же структурой и имеют большое количество методов. Чтобы посмотреть все методы, нужно после переменной со значением string поставить точку и посмотеть подсказку которую даст Swift

var string = "do or do not, there is no try"

print(string.lowercased())
print(string.uppercased())
print(string.capitalized(with: Locale.init(identifier: "Do")))
print(string.hasPrefix("Or")) // Когда всплывает подсказка можно посмотреть каке значения или методы можно использовать и как их использовать описано ниже
print(string.sorted())

// Properties and methods of arrays. Свойства и методы массивов
// Массивы тоже являются структурами. Можно посмотреть их методы так же как и строк

var toys = ["Woody"]

print(toys.count)
toys.append("Buzz")

toys.firstIndex(of: "Buzz")

// Initializers инициализаторы
// Можно создавать экземпляры структур двумя способами. 1 -  называется Memberwise initializer, при создании попросит указать занчение для каждого свойства в структуре 2 - custom initializer, создается структура(инициализируется) внутри структуры

struct User {
    var userName: String
    
    init() {
        userName = "Anonymous"
        print("Creating a new user")
    }
}

var user = User()
print(user.userName)

// Reffering to the current instance Ссылка на текущий экземпляр
// Специальная константа называемая self  с маленькой буквы. Часто используется при инициализации, когда имя свойства и параметра этого свойства пишутся одинаково

struct Person1 {
    var name: String
    
    init(name: String) {
        print("\(name) was born")
        self.name = name
    }
}

var person1 = Person1(name: "Buddy")

print(person1.name)




